package com.kzfire.portal.utils;

/**
 * @author ysf
 *静态常量类
 * 2014-8-13 下午3:11:47  
 */
public class Contents {
	   public  final static String LOGIN_USER="currentLoginUser";
}
