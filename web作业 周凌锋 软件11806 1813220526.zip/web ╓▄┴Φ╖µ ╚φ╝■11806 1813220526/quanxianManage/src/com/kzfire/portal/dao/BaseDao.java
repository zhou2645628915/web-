package com.kzfire.portal.dao;

import java.util.Map;

public interface BaseDao {

	int getTableCount(Map map);

}
